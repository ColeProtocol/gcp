package com.helloster.sterhello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SterhelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(SterhelloApplication.class, args);
	}

}
